package com.example.twosecvideocutter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val videoPicker = 41
    private val folderPicker = 42
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var progress: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var choose: Button
    private lateinit var chooseFolder: Button
    private lateinit var start: Button
    private lateinit var pause: Button
    private lateinit var resume: Button
    private lateinit var stop: Button
    private lateinit var durationChoices: RadioGroup
    private lateinit var trimStart: EditText
    private lateinit var trimEnd: EditText
    private lateinit var folderLabel: TextView

    @Volatile private var paused = false
    @Volatile private var stopped = false
    @Volatile private var running = false
    private val pauseLock = Object()
    private var videoUri: Uri? = null
    private var outputTreeUri: Uri? = null
    private var baseName = "video"
    private var clipSeconds = 2
    private var videoDurationUs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 28)
        }
        scroll.addView(root)
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        fun section(text: String) { root.addView(label(text, 17f)) }
        root.addView(label("2 Sec Video Cutter", 27f))
        root.addView(label("MP4 / MKV ভিডিও Trim করে ছোট ক্লিপে ভাগ করুন", 15f))

        choose = Button(this).apply {
            text = "ভিডিও নির্বাচন করুন"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "video/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(i, videoPicker)
            }
        }
        root.addView(choose, fullWidth())
        details = label("এখনো কোনো ভিডিও নির্বাচন করা হয়নি।")
        root.addView(details)

        section("ভিডিওর কোন অংশ Trim করবেন? (সেকেন্ডে)")
        val trimRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        trimStart = EditText(this).apply {
            hint = "শুরু (0)"; inputType = 8194; setText("0"); setSingleLine(true)
        }
        trimEnd = EditText(this).apply {
            hint = "শেষ (ভিডিওর শেষ)"; inputType = 8194; setSingleLine(true)
        }
        trimRow.addView(trimStart, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        trimRow.addView(trimEnd, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(trimRow, fullWidth())
        root.addView(label("সময় সেকেন্ডে লিখুন। Stream-copy কাটিং Keyframe অনুযায়ী সামান্য এদিক-ওদিক হতে পারে।", 13f))

        section("Output কোথায় সেভ হবে?")
        chooseFolder = Button(this).apply {
            text = "Output ফোল্ডার নির্বাচন করুন"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(i, folderPicker)
            }
        }
        root.addView(chooseFolder, fullWidth())
        folderLabel = label("ডিফল্ট: Movies/2SecVideoCutter")
        root.addView(folderLabel)

        section("প্রতি ক্লিপের দৈর্ঘ্য নির্বাচন করুন")
        durationChoices = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; gravity = Gravity.CENTER }
        listOf(2, 3, 5, 10, 15, 20, 30, 60).forEach { sec ->
            durationChoices.addView(RadioButton(this).apply {
                text = "${sec}s"; id = View.generateViewId(); isChecked = sec == 2
                setOnClickListener { clipSeconds = sec; updateVideoInfo() }
            })
        }
        root.addView(durationChoices)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, fullWidth())
        progressLabel = label("0%", 14f); root.addView(progressLabel)
        status = label("ভিডিও নির্বাচন করে কাটিং শুরু করুন।", 15f); root.addView(status)
        start = Button(this).apply { text = "Trim করে ক্লিপ কাটা শুরু করুন"; isEnabled = false; setOnClickListener { beginCutting() } }
        pause = Button(this).apply { text = "PAUSE"; isEnabled = false; setOnClickListener { pauseCutting() } }
        resume = Button(this).apply { text = "RESUME"; isEnabled = false; setOnClickListener { resumeCutting() } }
        stop = Button(this).apply { text = "STOP"; isEnabled = false; setOnClickListener { stopCutting() } }
        listOf(start, pause, resume, stop).forEach { root.addView(it, fullWidth()) }
        setContentView(scroll)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    @Deprecated("Kept for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == videoPicker) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
            baseName = displayName(uri).substringBeforeLast('.', "video").ifBlank { "video" }
            videoDurationUs = durationUs(uri)
            trimStart.setText("0")
            trimEnd.setText((videoDurationUs / 1_000_000.0).toString())
            updateVideoInfo()
            start.isEnabled = videoDurationUs > 0
        } else if (requestCode == folderPicker) {
            val flags = (data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
            outputTreeUri = uri
            folderLabel.text = "নির্বাচিত Output ফোল্ডার: ${treeDisplayName(uri)}"
        }
    }

    private fun treeDisplayName(uri: Uri): String = try {
        val docId = DocumentsContract.getTreeDocumentId(uri)
        docId.substringAfterLast(':', docId).ifBlank { "নির্বাচিত ফোল্ডার" }
    } catch (_: Exception) { "নির্বাচিত ফোল্ডার" }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "video"
        }
        return "video"
    }

    private fun durationUs(uri: Uri): Long {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(this, uri, null)
            (0 until ex.trackCount).mapNotNull { try { ex.getTrackFormat(it).getLong(MediaFormat.KEY_DURATION) } catch (_: Exception) { null } }.maxOrNull() ?: 0L
        } finally { ex.release() }
    }

    private fun trimRange(): Pair<Long, Long>? {
        val startSec = trimStart.text.toString().trim().toDoubleOrNull() ?: 0.0
        val endText = trimEnd.text.toString().trim()
        val endSec = if (endText.isBlank()) videoDurationUs / 1_000_000.0 else endText.toDoubleOrNull() ?: return null
        if (startSec < 0 || endSec <= startSec || endSec > videoDurationUs / 1_000_000.0 + 0.001) return null
        return (startSec * 1_000_000).toLong() to minOf((endSec * 1_000_000).toLong(), videoDurationUs)
    }

    private fun updateVideoInfo() {
        val uri = videoUri ?: return
        if (videoDurationUs <= 0) { status.text = "ভিডিওর দৈর্ঘ্য পড়া যায়নি।"; return }
        val range = trimRange()
        if (range == null) {
            details.text = "ভিডিও: ${displayName(uri)}\nদৈর্ঘ্য: ${timeText(videoDurationUs / 1_000_000.0)}\nTrim সময় সঠিকভাবে দিন।"
            return
        }
        val selectedDur = range.second - range.first
        val count = ((selectedDur + clipSeconds * 1_000_000L - 1) / (clipSeconds * 1_000_000L)).toInt()
        details.text = "ভিডিও: ${displayName(uri)}\nমোট দৈর্ঘ্য: ${timeText(videoDurationUs / 1_000_000.0)}\nTrim: ${timeText(range.first / 1_000_000.0)} – ${timeText(range.second / 1_000_000.0)}\nক্লিপ হবে: $count টি"
        status.text = "প্রতি ক্লিপ $clipSeconds সেকেন্ড।"
    }

    private fun beginCutting() {
        val uri = videoUri ?: return
        if (running) return
        val range = trimRange()
        if (range == null) { status.text = "Trim Start/End সঠিকভাবে দিন।"; return }
        paused = false; stopped = false; running = true
        setBusy(true); progress.visibility = View.VISIBLE; progress.progress = 0; progressLabel.text = "0%"
        status.text = "কাটিং শুরু হচ্ছে…"
        val startUs = range.first
        val endUs = range.second
        worker.execute {
            val startedAt = System.currentTimeMillis()
            var made = 0
            try {
                val segment = clipSeconds * 1_000_000L
                val total = ((endUs - startUs + segment - 1) / segment).toInt()
                for (i in 0 until total) {
                    waitWhilePaused()
                    if (stopped) break
                    val from = startUs + i * segment
                    val to = minOf(from + segment, endUs)
                    exportClip(uri, from, to, i + 1)
                    made++
                    val pct = (made * 100.0 / total).roundToInt()
                    val remain = ((System.currentTimeMillis() - startedAt).toDouble() / made * (total - made) / 1000.0)
                    runOnUiThread {
                        progress.progress = pct
                        progressLabel.text = "$pct%  •  $made / $total ক্লিপ"
                        status.text = "তৈরি: $made টি  |  বাকি: ${total - made} টি\nআনুমানিক বাকি সময়: ${timeText(remain)}"
                    }
                }
                runOnUiThread {
                    status.text = if (stopped) "Stop করা হয়েছে। $made টি ক্লিপ সেভ হয়েছে।" else "সম্পন্ন! $made টি ক্লিপ নির্বাচিত Output ফোল্ডারে সেভ হয়েছে।"
                    if (!stopped) { progress.progress = 100; progressLabel.text = "100%" }
                    running = false; setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "সমস্যা: ${e.message ?: "ভিডিও প্রসেস করা যায়নি"}"; running = false; setBusy(false) }
            }
        }
    }

    private fun waitWhilePaused() {
        synchronized(pauseLock) { while (paused && !stopped) pauseLock.wait() }
    }
    private fun pauseCutting() {
        if (!running) return
        paused = true; pause.isEnabled = false; resume.isEnabled = true
        status.text = "Pause করা হয়েছে। Resume চাপলে আবার চলবে।"
    }
    private fun resumeCutting() {
        if (!running) return
        synchronized(pauseLock) { paused = false; pauseLock.notifyAll() }
        pause.isEnabled = true; resume.isEnabled = false
    }
    private fun stopCutting() {
        if (!running) return
        stopped = true
        synchronized(pauseLock) { paused = false; pauseLock.notifyAll() }
        stop.isEnabled = false; status.text = "Stop করা হচ্ছে… চলমান ক্লিপ শেষ হলে থামবে।"
    }
    private fun setBusy(busy: Boolean) {
        choose.isEnabled = !busy; chooseFolder.isEnabled = !busy; start.isEnabled = !busy && videoUri != null
        trimStart.isEnabled = !busy; trimEnd.isEnabled = !busy
        for (i in 0 until durationChoices.childCount) durationChoices.getChildAt(i).isEnabled = !busy
        pause.isEnabled = busy; resume.isEnabled = false; stop.isEnabled = busy
    }

    private fun createOutput(name: String): Pair<Uri, android.os.ParcelFileDescriptor> {
        val tree = outputTreeUri
        if (tree != null) {
            val docId = DocumentsContract.getTreeDocumentId(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            val out = DocumentsContract.createDocument(contentResolver, parent, "video/mp4", name)
                ?: error("নির্বাচিত Output ফোল্ডারে ফাইল তৈরি করা যায়নি")
            val pfd = contentResolver.openFileDescriptor(out, "w") ?: error("Output ফাইল খোলা যায়নি")
            return out to pfd
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/2SecVideoCutter")
        }
        val out = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("আউটপুট ফাইল তৈরি করা যায়নি")
        val pfd = contentResolver.openFileDescriptor(out, "w") ?: error("আউটপুট ফাইল খোলা যায়নি")
        return out to pfd
    }

    private fun exportClip(uri: Uri, fromUs: Long, toUs: Long, number: Int) {
        val extractor = MediaExtractor()
        var outUri: Uri? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var wroteSample = false
        try {
            extractor.setDataSource(this, uri, null)
            val tracks = mutableMapOf<Int, Int>()
            for (track in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(track)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) tracks[track] = track
            }
            check(tracks.isNotEmpty()) { "ভিডিও/অডিও ট্র্যাক পাওয়া যায়নি" }
            extractor.seekTo(fromUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val name = "${baseName}_${number.toString().padStart(4, '0')}.mp4"
            val output = createOutput(name)
            outUri = output.first; pfd = output.second
            muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outputTracks = mutableMapOf<Int, Int>()
            tracks.keys.forEach { track -> outputTracks[track] = muxer.addTrack(extractor.getTrackFormat(track)); extractor.selectTrack(track) }
            muxer.start(); muxerStarted = true
            val buffer = ByteBuffer.allocate(16 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var originPts = -1L
            while (true) {
                val track = extractor.sampleTrackIndex
                if (track < 0) break
                val pts = extractor.sampleTime
                if (pts >= toUs) break
                if (outputTracks.containsKey(track)) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    if (originPts < 0 || pts < originPts) originPts = pts
                    info.set(0, size, max(0L, pts - originPts), extractor.sampleFlags)
                    muxer.writeSampleData(outputTracks[track]!!, buffer, info)
                    wroteSample = true
                }
                if (!extractor.advance()) break
            }
            check(wroteSample) { "এই Trim অংশে কোনো মিডিয়া Sample পাওয়া যায়নি। Start/End সময় পরিবর্তন করুন।" }
            if (muxerStarted) { muxerStarted = false; muxer.stop() }
        } catch (e: Exception) {
            outUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
            throw e
        } finally {
            if (muxerStarted) try { muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    private fun timeText(seconds: Double): String {
        val s = max(0, seconds.roundToInt()); val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%02d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    override fun onDestroy() {
        synchronized(pauseLock) { stopped = true; paused = false; pauseLock.notifyAll() }
        worker.shutdown()
        super.onDestroy()
    }
}
